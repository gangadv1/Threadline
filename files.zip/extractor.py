"""
extractor.py
============
This is the heart of your Role 2 job: take raw text -> call the LLM ->
get back a guaranteed-valid ExtractionResult object.

HOW STRUCTURED OUTPUTS WORKS (in plain English):
- Normally, asking an LLM for JSON is unreliable — it might add commentary,
  miss a field, or produce invalid JSON.
- OpenAI's `.beta.chat.completions.parse()` method fixes this: you pass in
  your Pydantic class as `response_format`, and the API is CONSTRAINED to
  only output JSON matching that exact schema. It also auto-validates the
  result back into a Python object for you (`.choices[0].message.parsed`).

You don't need to touch any of the schema definitions here — just import
them from schemas.py.
"""

import os
from openai import OpenAI

from schemas import ExtractionResult
from prompts import SYSTEM_PROMPT

# ---------------------------------------------------------------------------
# 1. Set up the OpenAI client.
#    NEVER hard-code your API key in this file. Instead:
#      - Create a file named `.env` in this same folder containing:
#            OPENAI_API_KEY=sk-your-key-here
#      - Add `.env` to your .gitignore so it never gets pushed to GitHub!
#    The line below reads that environment variable automatically.
# ---------------------------------------------------------------------------
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

# Structured Outputs currently works best on these model families.
# gpt-4o-mini is cheap and fast — great for a hackathon. Swap to gpt-4o
# if you find extraction quality needs to be higher.
MODEL_NAME = "gpt-4o-mini"


def extract_tasks_from_text(raw_text: str) -> ExtractionResult:
    """
    The one function Role 3 (Backend) needs to call.

    Parameters
    ----------
    raw_text : str
        The messy email body / PDF-extracted text you want analyzed.

    Returns
    -------
    ExtractionResult
        A validated Python object (not a raw dict!). Access fields like:
            result.tasks[0].task_name
            result.tasks[0].deadline
        If you need a plain dict/JSON to hand off to another teammate's
        service, call `.model_dump()` or `.model_dump_json()` on it.
    """

    if not raw_text or not raw_text.strip():
        raise ValueError("raw_text is empty — nothing to extract from.")

    response = client.beta.chat.completions.parse(
        model=MODEL_NAME,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": (
                    "Extract all tasks, deadlines, dependencies, and required "
                    "documents from the following source text:\n\n"
                    f"---BEGIN SOURCE TEXT---\n{raw_text}\n---END SOURCE TEXT---"
                ),
            },
        ],
        response_format=ExtractionResult,  # <-- this is the whole trick
        temperature=0.2,  # low temperature = more consistent, less "creative"
    )

    parsed: ExtractionResult = response.choices[0].message.parsed

    # Belt-and-suspenders: .parse() already guarantees schema validity,
    # but the model can still refuse (e.g. safety reasons). Handle that:
    if parsed is None:
        refusal = response.choices[0].message.refusal
        raise RuntimeError(f"Model refused to extract: {refusal}")

    return parsed


# ---------------------------------------------------------------------------
# Quick manual test — run `python extractor.py` directly to try it out.
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    sample_email = """
    Subject: Important - Student Pass & Housing Steps

    Dear Student,

    Please note that all incoming exchange students must apply for their
    Student's Pass through ICA within 2 weeks of receiving their In-Principle
    Approval (IPA) letter. You will need a valid passport and one recent
    passport photo.

    Separately, hostel move-in requires your housing deposit of $500 to be
    paid by 15 August 2026. Rooms are only released after payment clears.

    Course bidding opens after your matriculation is confirmed, which itself
    only happens once tuition fees are settled.
    """

    result = extract_tasks_from_text(sample_email)
    print(result.model_dump_json(indent=2))
